<!-- task list -->

<div class="row rowTaskList">

    <div class="col-md-6 col-sm-12 col-xs-12">

        <div class="firstTask">

            <div class="table-responsive">

                <table class="table">

                    <thead style="border: none;">
                        <th style="border: none; width: 10em;">Today</th>
                        <th style="border: none; width: 3em;"><i class="fas fa-user"></i></th>
                    </thead>

                </table>

            </div>

        </div>

    </div>

</div>

<!-- end task list -->


<script>



</script>