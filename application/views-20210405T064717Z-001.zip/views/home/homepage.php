<div class="col-lg-9 col-md-9 mainTab">

  <!-- header -->

  <div class="header">

    <ul class="nav justify-content-end">
      <li class="nav-item" onclick="addTaskModal()">
        <a class="nav-link" href="#"><i class="fas fa-plus"></i></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><img src="<?= base_url(); ?>/assets/images/bell.png" width="20" height="20" alt=""></a>
      </li>
      <li class="nav-item" onclick="logout()">
          <a class="nav-link" href="#"><img class="userAvatar" src="<?= base_url(); ?>/assets/images/businessman.png" width="30" height="30" alt=""></a>
      </li>
    </ul>

  </div>

  <!-- end header -->

  <!-- main -->

  <div class="main">

    <div class="todayTitle">

      <span class="spanTodayTitle">today</span><span class="spanDate">, <?= date('d F Y'); ?></span>

    </div>

    <!-- background with condition -->

    <div class="background">

      <img src="<?= base_url(); ?>/assets/images/background1.png" width="600" height="450" alt="">
      <p style="font-family: var(--sfpd-regular); color: #fff; font-size: 0.9em;">Enjoy your night palls!</p>
      <p style="font-family: var(--sfpd-light); color: var(--suva-gray); font-size: 0.8em;">Nothing task for today</p>

    </div>

    <!-- end background with condition -->

    <!-- today table -->

    <div class="table-responsive todayTable">

      <table class="table">

        <thead>

          <th class="targetOwnerTask" colspan="3"></th>

        </thead>

        <tbody class="targetTodo">

        </tbody>

      </table>

    </div>

    <div class="table-responsive taskDoneTable">

      <table class="table">

        <thead>

          <th class="thTodayTable" colspan="3">Task Done (Archive)</span></th>

        </thead>

        <tbody class="targetTaskDone">

        </tbody>

      </table>

    </div>

    <!-- end today table -->

  </div>

  <!-- end main -->

  <!-- user management tab -->

  <div class="userManagement">

    <div class="table-resposive">

      <table class="table">

        <thead>
          <tr style="border-bottom: 1px solid var(--silver);">
            <th colspan="4" style="font-family: var(--sfpd-regular); font-size: 0.9em; color: #fff;">User management</th>
          </tr>
        </thead>

        <tbody class="targetUserManagement">
          <!-- <tr sytle="border-bottom: 1px solid var(--suva-gray)''">
            <td style="width: 1em; vertical-align: middle;">
              <i class="fas fa-dot-circle"></i>
            </td>
            <td style="width: auto; vertical-align: middle;">
              <p class="userName">ilham meru gumilang</p>
              <p class="userActivity">3 Task on going now</p>
            </td>
            <td style="width: auto; vertical-align: middle;">
              <p class="statusUser">active</p>
            </td>
            <td style="width: 5em; vertical-align: middle;">
              <div class="btn-group">
                <button type="button" class="btn" name="button"> <i class="fas fa-power-off"></i> </button>
                <button type="button" class="btn" name="button"> <i class="fas fa-trash userTrash"></i> </button>
              </div>
            </td>
          </tr> -->
        </tbody>

      </table>

    </div>

  </div>

  <!-- user management tab -->

</div>



<!-- modal detail task -->

<div class="modal modalDetailTask fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">

    <div class="modal-content contentDetail">

      <div class="modal-header headerDetail">
        <h5 class="modal-title" id="staticBackdropLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body targetBodyDetail">

        <div class="headerDetailSubtask">

          <img class="" src="<?= base_url(); ?>/assets/images/radio.png" width="25" height="25" alt="" />
          <span class="targetTitleDetail"></span>

          <div class="row parentTabsDetail">

            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 activeTab" id="subtaskTab">

              <span style="text-transform: capitalize; font-family: var(--sfpd-regular); font-size: 0.9em;">sub-task</span>

            </div>

            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 comments" id="commentsTab">

              <span style="text-transform: capitalize; font-family: var(--sfpd-regular); font-size: 0.9em;">Comments <span class="commentRow"></span> </span>

            </div>

          </div>

        </div>

        <div class="flexibleDetail">

          <div class="targetSubtask">

            <div class="table-responsive">

              <table class="table">

                <tbody class="targetDetailSubtask">

                </tbody>

              </table>

            </div>

            <div class="table-responsive">

              <table class="table">

                <tbody class="targetSubtaskDone">

                </tbody>

              </table>

            </div>

          </div>

          <div class="targetActivity" style="display: none;">

            <div class="detailActivity">

              <div class="chatColomn">

                <div style="display: flex; margin-bottom: 2.5em;">

                  <div class="tdIcon">
                    <span><?= substr($_SESSION['name'], 0, 1); ?></span>
                  </div>

                  <div class="">
                    <p class="senderComment">gumilang.dev@gmail.com <span class="timeComment"> 04 Apr 04:23</span> </p>
                    <p class="messageComment">Masih ada yang salah ini, ada yang kurang</p>
                  </div>

                </div>

              </div>

              <div class="typeComments">

                <textarea type="text" class="font-control commentsValue" name="commentsvalue" placeholder="Type comments ..." rows="3"></textarea>

                <div class="actionComments">

                  <button type="button" class="btn saveComments" name="button">Add Comment</button>

                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>

  </div>

</div>

<!-- modal detail task -->

<!-- modal add task -->

<!-- Modal -->
<div class="modal modalQuickTask fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="background: #202020; border: none;">
      <div class="modal-header" style="border: none;">
        <span class="modal-title" id="staticBackdropLabel" style="font-family: var(--sfpd-medium); color: #fff; font-size: 0.8em; text-transform: capitalize;">quick add task</span>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="quickForm">
          <input type="text" autocomplete="off" name="fieldQuickForm" class="fieldQuickForm" id="fieldQuickForm" oninput="activeButton('quick add', 'fieldQuickForm')" placeholder="e.g family lunch on sunday">
        </div>
        <div class="buttonGroupAdd" style="display: block;">
          <button type="button" class="doAddTask" id="buttonQuickForm" name="button">Add Task</button>
          <span onclick="cancelAddTask()">Cancel</span>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- end modal add task -->

<!-- popover body -->

<div id="customdiv" style="display: none;">

  <ul class="list-group">
    <li class="list-group-item">

      <span>Edit task</span>
    </li>
    <li class="list-group-item">
      <img src="<?= base_url(); ?>/assets/images/trash1.png" width="18" height="18" alt="">
      <span>Delete task</span>
    </li>
  </ul>

</div>

<!-- end popover body -->

<!-- toast -->

<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 5">
  <div id="liveToast" class="toast hide" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header">
      <span class="me-auto">Updated</span>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
    <div class="toast-body targetToast">
    </div>
  </div>
</div>

<!-- end toast -->

<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="https://unpkg.com/tippy.js@6"></script>
<script type="text/javascript">

  $(document).ready(function() {

    getTask();
    // enterFunction();
    enterFunctionSubtask();

    $('#commentsTab').click(function(e) {
      e.preventDefault();

      $('#subtaskTab').removeClass('activeTab');

      $(this).addClass('activeTab');
      $('.targetActivity').show();
      $('.targetSubtask').hide();
    })

    $('#subtaskTab').click(function(e) {
      e.preventDefault();

      $('#commentsTab').removeClass('activeTab');

      $(this).addClass('activeTab');
      $('.targetActivity').hide();
      $('.targetSubtask').show();
    })

  })

  function cancelAddTask() {

    $('.taskForm').hide();
    $('.buttonGroupAdd').hide();

    $('.buttonTaskForm').show();
    getTask();

  }

  function activeButton(condition, field) {

    var task = $('.' + field).val();

    if(task.length > 0) {

      $('.doAddTask').addClass('activeForButton');
      $('.doAddTask').attr('onclick', "saveTask('"+ condition +"', '"+ field +"')");

    } else {

      $('.doAddTask').removeClass('activeForButton');
      $('.doAddTask').removeAttr('onclick');

    }

  }

  function saveTask(condition = '', field = '') {

    var task = $('.' + field).val();

    $.ajax({
      type: 'post',
      data: {
        task: task
      },
      url: '<?= base_url('Task/saveTask'); ?>',
      dataType: 'text',
      success: function(result) {
        getTask();

        if(condition == 'quick add') {

          $('.modalQuickTask').modal('hide');

        }
      }
    })

  }

  function getTask(userId = '') {

    var idMaster = '<?= $_SESSION['id']; ?>';

    $.ajax({
      type: 'POST',
      data: {
        userId: userId
      },
      url: '<?= base_url('Task/getTask'); ?>',
      dataType: 'json',
      success: function(result) {

        if(result.todo == 0) {

          $('.todayTable').hide();
          $('.background').show();
          $('.taskDoneTable').hide();

        } else if (result.todo.length > 0) {

          $('.todayTable').show();
          $('.background').hide();

          var tr = '';
          var taskDone = '';

          var tom = "'tomorrow'";
          var next = "'week'";

          for (var i = 0; i < result.todo.length; i++) {

            // condition subtask

            if (result.todo[i].active_subtask == 0) {

              var subtask = '';

            } else {

              var subtask = '<div class="subTask">' +
                          '<img src="<?= base_url(); ?>/assets/images/subtask.png" width="18" height="18" alt="">' +
                          '<span style="font-family: var(--sfpd-ultralight); font-size: 0.8em; color: var(--suva-gray);">'+ result.todo[i].inactive_subtask + '/' + (result.todo[i].active_subtask + result.todo[i].inactive_subtask) + '</span>' +
                          '</div>';

            }

            //condition comment
            if (result.comment[0].length > 0) {

              var tdComment = '<div class="taskComment" style="margin-left: 0.8em;">' +
                          '<i class="far fa-comment"></i>' +
                          '<span style="font-family: var(--sfpd-ultralight); font-size: 0.8em; color: var(--suva-gray);">'+ result.comment[i].length + '</span>' +
                          '</div>';

            } else {

              var tdComment = '';

            }

            // condition status
            if (result.status[i] == 1) {

              var taskValue = "'"+ result.todo[i].todo +"'";
              var paramDetail = "'task'";

              var param = "'manual', 'task'";

              if (result.userId[i] != idMaster) {

                var action = '';
                var buttonTime1 = '';
                var buttonTime2 = '';
                var buttonDelete = '';
                var buttonEdit = '';
                var onclickUser = "'other'";

              } else {

                var action = '<tr class="newTask" style="border: none;">' +
                          '<td colspan="2" style="border:none; color: var(--suva-gray); font-family: var(--sfpd-light); font-size: 0.9em;">' +
                          '<div class="taskForm">' +
                          '<input type="text" autocomplete="off" name="task" class="task" value="" oninput="activeButton('+ param +')" placeholder="e.g family lunch on sunday">' +
                          '</div>' +
                          '<div class="buttonGroupAdd">' +
                          '<button type="button" class="doAddTask" name="button">Add Task</button>' +
                          '<span onclick="cancelAddTask()">Cancel</span>' +
                          '</div>' +
                          '<div class="buttonTaskForm" onclick="buttonTaskForm()">' +
                          '<img class="" src="<?= base_url(); ?>/assets/images/plus.png" width="18" height="18" alt="" /><span> add task</span>' +
                          '</div>' +
                          '</td>' +
                          '</tr>';

                var buttonDelete = '<button onclick="confirmDeleteTask('+ result.taskId[i] +')" class="btn btnPopover tomorrowPopover" id="editPopover"><i class="fas fa-trash"></i></button>';
                var buttonEdit = '<button onclick="editTask('+ result.taskId[i] +', '+ i +', '+ taskValue +')" class="btn btnPopover tomorrowPopover" id="editPopover"><i class="fas fa-edit"></i></button>';
                var buttonTime1 = '<button onclick="getDeadline('+ result.taskId[i] +', '+ next +')" class="btn btnPopover weekPopover" id="weekPopover"><i class="fas fa-calendar-week"></i></button>';
                var buttonTime2 = '<button onclick="getDeadline('+ result.taskId[i] +', '+ tom +')" class="btn btnPopover tomorrowPopover" id="tomorrowPopover"><i class="fas fa-sun"></i></button>';
                var onclickUser = "'self'";

              }

              tr += '<tr data-helper-task="1" class="trTodo" id="trTodo'+ i +'">' +
                '<td class="iconTodayTable" onclick="taskDone('+ i +', '+ result.taskId[i] +', '+ onclickUser +')"><img class="" src="<?= base_url(); ?>/assets/images/radio.png" width="25" height="25" alt="" /></td>' +
                '<td class="descTodayTable" onclick="detailTask('+ i +', '+ result.taskId[i] +', '+ paramDetail +')">' +
                '<p style="margin-bottom: 0;">'+ result.todo[i].todo +'</p>' +
                '<div style="display: flex;">' +
                subtask +
                tdComment +
                '</div>' +
                '</td>' +
                '<td class="tdAction coba'+ i +'" data-id="1" id="testing'+ i +'">' +
                '<div class="btn-group">' +
                buttonTime1 +
                buttonTime2 +
                buttonEdit +
                buttonDelete +
                '</div>' +
                '</td>' +
                '</tr>';

            } else {

              taskDone += '<tr onclick="redoTask('+ i +', '+ result.taskId[i] +')" data-helper-task-done="1" class="trTaskDone" id="trTodo'+ i +'">' +
                '<td class="iconTodayTable"><img class="" src="<?= base_url(); ?>/assets/images/radiocheck.png" width="25" height="25" alt="" /></td>' +
                '<td class="descTodayTable">' +
                '<p style="margin-bottom: 0; text-decoration: line-through; color: var(--dim-gray);">'+ result.todo[i].todo +'</p>' +
                subtask +
                '</td>' +
                '<td class="tdAction coba'+ i +'" data-id="1" id="testing'+ i +'">' +
                '<i class="fas fa-plus"></i>' +
                '</td>' +
                '</tr>';

            }

            //add onclick
            $('.divTodayPopover').attr('onclick', 'getDeadline('+ result.taskId[i] +')');

          }

          $('.targetTodo').html(tr);
          $('.targetTodo').append(action);

          $(".task").on('keyup', function (event) {
              if (event.keyCode === 13) {

                saveTask('manual', 'task');
                getTask();

              }
          });

          $('.targetTaskDone').html(taskDone);

          //condition owner name
          $('.targetOwnerTask').html(result.name);

          //condition showing table
          var helperTaskDone = $('tr[class="trTaskDone"]').map(function() {
            return $(this).attr('data-helper-task-done');
          }).toArray();

          var helperTask = $('tr[class="trTodo"]').map(function() {
            return $(this).attr('data-helper-task');
          }).toArray();

          if (helperTaskDone.length > 0) {

            $('.taskDoneTable').show();

          } else {

            $('.taskDoneTable').hide();

          }

          if (helperTask.length > 0) {

            $('.todayTable').show();

          } else {

            $('.todayTable').hide();

          }

          // initialize popover
          tippy('#editPopover', {
            content: 'Edit',
          });

          tippy('#tomorrowPopover', {
            content: 'Tomorrow',
          });

          tippy('#weekPopover', {
            content: 'Next week',
          });

        }

      }
    })

  }

  function buttonTaskForm() {

    $('.taskForm').show();
    $('.buttonGroupAdd').show();

    $('.buttonTaskForm').hide();

    $('.task').focus();

  }

  function enterFunction(condition = '', field) {

    $('.' + field).on('keyup', function (event) {
        if (event.keyCode === 13) {

          saveTask(condition, field);
          getTask();

        }
    });

  }

  function enterFunctionSubtask() {

    $(".subtaskField").on('keyup', function (event) {
        if (event.keyCode === 13) {

          saveSubtask();
          // getSubtask();

        }
    });

  }

  function detailTask(idForm, taskId, paramDetail) {

    $('.modalDetailTask').modal('show');

    $.ajax({
      type: 'post',
      data: {
        id: taskId,
        paramDetail: paramDetail
      },
      url: '<?= base_url('Task/detailTask'); ?>',
      dataType: 'json',
      success: function(result) {
        if(result.title != '') {

          $('.targetTitleDetail').text(result.title);

          getSubtask(taskId, result.statusUser);
          getComment(taskId, result.statusUser);
          $('.saveComments').attr('onclick', 'saveComment('+ taskId +')');

        }

      }
    })

  }

  function showSubtaskForm() {

    $('.subtaskForm').show();
    $('.buttonGroupAddSubtask').show();

    $('.buttonSubtask').hide();

  }

  function cancelAddSubtask(taskId = '') {

    $('.subtaskForm').hide();
    $('.buttonGroupAddSubtask').hide();

    $('.buttonSubtask').show();
    getSubtask(taskId);

  }

  function checkSubtask() {

    var subtask = $('.subtaskField').val();

    if(subtask.length > 0) {

      $('.doAddSubtask').addClass('activeForButton');
      $('.doAddSubtask').attr('onclick', 'saveSubtask()');

    } else {

      $('.doAddSubtask').removeClass('activeForButton');
      $('.doAddSubtask').removeAttr('onclick');

    }

  }

  function saveSubtask() {

    var subtask = $('.subtaskField').val();
    var taskId = $('.taskId').val();

    $.ajax({
      type: 'post',
      data: {
        subtask: subtask,
        taskId: taskId
      },
      url: '<?= base_url('Task/saveSubtask'); ?>',
      dataType: 'text',
      success: function(result) {
        getTask();
        getSubtask(taskId);
      }
    })

  }

  function addTaskModal() {

    $('.modalQuickTask').modal('show');

    enterFunction('quick add', 'fieldQuickForm');

    getTask();

  }

  function getSubtask(taskId, param) {

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId,
        param: param
      },
      url: '<?= base_url('Task/getSubtask'); ?>',
      dataType: 'json',
      success: function(result) {
        console.log(result);

        //condition role user
        if (result.params == 'other') {

          var buttonAction = '';

        } else {

          var buttonAction = '<tr class="newSubtask" style="border: none;">' +
                          '<td colspan="2" style="border:none; color: var(--suva-gray); font-family: var(--sfpd-light); font-size: 0.9em;">' +
                          '<div class="subtaskForm">' +
                          '<input type="text" autocomplete="off" name="subtaskField" class="subtaskField" oninput="checkSubtask()" placeholder="e.g family lunch on sunday">' +
                          '<input type="hidden" name="taskId" class="taskId">' +
                          '</div>' +
                          '<div class="buttonGroupAddSubtask">' +
                          '<button type="button" class="doAddSubtask" name="button">Add Task</button>' +
                          '<span onclick="cancelAddSubtask()" style="cursor: pointer;">Cancel</span>' +
                          '</div>' +
                          '<div class="buttonSubtask" onclick="showSubtaskForm()">' +
                          '<img class="" src="<?= base_url(); ?>/assets/images/plus.png" width="18" height="18" alt="" /><span> Add Sub-task</span>' +
                          '</div>' +
                          '</td>' +
                          '</tr>';

        }

        var tr = '';
        var subtaskDone = '';
        for(var i = 0; i < result.allSubtask; i++) {

          var undo = "'undo'";
          var redo = "'redo'";
          var tom = "'tomorrow'";
          var next = "'week'";
          var tod = "'today'";
          var key = "'subtask'";

          // condition deadline
          var today1 = '<?= date('l'); ?>';
          var tom1 = '<?= date('l', strtotime('+1 days')); ?>';
          var next1 = '<?= date('l', strtotime('+7 days')); ?>';

          var t = '<?= date('Y-m-d'); ?>';
          var tm = '<?= date('Y-m-d', strtotime('+1 days')); ?>';
          var w = '<?= date('Y-m-d', strtotime('+7 days')); ?>';

          if (result.subtask[i]['deadlineSub'] != 0) {

            var todayTime = new Date();
            var y = todayTime.getFullYear();
            var m = addZero((todayTime.getMonth() + 1));
            var d = addZero(todayTime.getDate());
            var newTodayTime = y + '-' + m + '-' + d;
            var x = new Date(newTodayTime).getTime();
            var deadlineDb = new Date(result.subtask[i]['deadlineSub']).getTime();

          }


          if (result.subtask[i]['deadlineSub'] == tm) {

            var spanDeadline = '<i id="calendarSubtask'+ i +'" class="far fa-calendar tomorrow"></i><span class="tomorrowSubtask" id="deadlineSubtaskIndicator'+ i +'">'+ tom1 +'</span>';

          } else if (result.subtask[i]['deadlineSub'] == t) {

            var spanDeadline = '<i id="calendarSubtask'+ i +'" class="far fa-calendar today"></i><span class="todaySubtask" id="deadlineSubtaskIndicator'+ i +'">Today</span>';

          } else if (result.subtask[i]['deadlineSub'] == w) {

            var spanDeadline = '<i id="calendarSubtask'+ i +'" class="far fa-calendar week"></i><span class="weekSubtask" id="deadlineSubtaskIndicator'+ i +'">'+ next1 +'</span>';

          } else if (x > deadlineDb){

            var spanDeadline = '<i id="calendarSubtask'+ i +'" class="far fa-calendar overdue"></i><span class="overdueSubtask" id="deadlineSubtaskIndicator'+ i +'">Ovedue</span>';

          } else {

            var spanDeadline = '';

          }

          //value subtask
          var value = "'"+ result.subtask[i]['sub'] +"'";

          //condition button
          if (result.params == 'other') {

            var buttonTime1 = '';
            var buttonTime2 = '';
            var buttonTime3 = '';
            var buttonTime4 = '';
            var buttonEdit = '';
            var buttonDelete = '';
            var onclickDone = '';

          } else {

            var key = "'"+ result.params +"'";

            var buttonTime1 = '<button onclick="addDeadline('+ taskId +', '+ next +', '+ key +', '+ i +', '+ key +')" class="btn btnPopover weekPopover" id="weekPopover"><i class="fas fa-calendar-week"></i></button>';
            var buttonTime2 = '<button onclick="addDeadline('+ taskId +', '+ tom +', '+ key +', '+ i +', '+ key +')" class="btn btnPopover tomorrowPopover" id="tomorrowPopover"><i class="fas fa-sun"></i></button>';
            var buttonTime3 = '<button onclick="addDeadline('+ taskId +', '+ tod +', '+ key +', '+ i +', '+ key +')" class="btn btnPopover todayPopoverr" id="todayPopoverr"><i class="fas fa-calendar-day"></i></button>';
            var buttonTime4 = '<button onclick="deleteDeadlineSubtask('+ taskId +', '+ tod +', '+ key +', '+ i +', '+ key +')" class="btn btnPopover todayPopoverr" id="todayPopoverr"><i class="far fa-calendar-times"></i></button>';
            var buttonEdit = '<button onclick="editSubtask('+ taskId +', '+ i +', '+ value +', '+ key +')" class="btn btnPopover tomorrowPopover" id="editPopover"><i class="fas fa-edit"></i></button>';
            var buttonDelete = '<button onclick="confirmDeleteSubtask('+ taskId +', '+ i +', '+ key +')" class="btn btnPopover tomorrowPopover" id="editPopover"><i class="fas fa-trash"></i></button>';
            var onclickDone = 'subtaskDone('+ i +', '+ taskId +', '+ undo +', '+ key +')';
            var onclickDone1 = 'subtaskDone('+ i +', '+ taskId +', '+ redo +', '+ key +')';

          }

          if (result.subtask[i]['status'] == 0) {

            tr += '';
            subtaskDone += '<tr id="trSubtask'+ i +'">' +
                '<td onclick="'+ onclickDone +'" style="width: 2em; border-color: #4d4c4c;"><img class="" src="<?= base_url(); ?>/assets/images/radiocheck.png" width="25" height="25" alt="" /></td>' +
                '<td onclick="'+ onclickDone +'" class="descSubtask">' +
                '<p style="margin-bottom: 0; text-decoration: line-through; color: var(--dim-gray);">'+ result.subtask[i]['sub'] +'</p>' +
                '</td>' +
                '</tr>';

          } else {

            tr += '<tr id="trSubtask'+ i +'">' +
                '<td onclick="'+ onclickDone1 +'" style="width: 2em; border-color: #4d4c4c;"><img class="" src="<?= base_url(); ?>/assets/images/radio.png" width="25" height="25" alt="" /></td>' +
                '<td onclick="'+ onclickDone1 +'" class="descSubtask">' +
                '<p style="margin-bottom: 0;">'+ result.subtask[i]['sub'] +'</p>' +
                spanDeadline +
                '</td>' +
                '<td style="width: 1em; border-bottom: 1px solid #4d4c4c; vertical-align: middle;">' +
                '<div class="btn-group">' +
                buttonTime1 +
                buttonTime2 +
                buttonTime3 +
                buttonTime4 +
                buttonEdit +
                buttonDelete +
                '</div>' +
                '</td>' +
                '</tr>';

          }

        }

        $('.targetDetailSubtask').html(tr);
        $('.targetDetailSubtask').append(buttonAction);
        $('.taskId').val(taskId);
        $(".subtaskField").on('keyup', function (event) {
            if (event.keyCode === 13) {

              saveSubtask();

            }
        });

        // subtask done
        $('.targetSubtaskDone').html(subtaskDone);

        //popover intialize
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
          return new bootstrap.Popover(popoverTriggerEl, {
            container: 'body',
            trigger: 'click',
            placement: 'right',
            html: true,
            content: function() {
              return $('#customdiv').html();
            }
          })
        });

      }
    })

  }

  function taskDone(taskKey, taskId, key ) {

    var idMaster = '<?= $_SESSION['id']; ?>';

    if (key == 'self') {

      $.ajax({
        type: 'post',
        data: {
          taskId: taskId
        },
        url: '<?= base_url('Task/taskDone'); ?>',
        dataType: 'json',
        success: function(result) {

          if (result.message == 'success') {

            getTask();

          }

        }
      })

    }

  }

  function redoTask(taskKey, taskId) {

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId
      },
      url: '<?= base_url('Task/redoTask'); ?>',
      dataType: 'json',
      success: function(result){

        if (result.message == 'success') {

          getTask();

        }

      }
    })

  }

  function subtaskDone(subtaskKey, taskId, param, key) {

    $.ajax({
      type: 'post',
      data: {
        subtaskKey: subtaskKey,
        taskId: taskId,
        param: param
      },
      url: '<?= base_url('Task/subtaskDone'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          getSubtask(taskId, key);
          getTask();

        }

      }
    })

  }

  function getDeadline(taskId, param) {

    $.ajax({
      type: 'post',
      data: {
        param: param,
        taskId: taskId
      },
      url: '<?= base_url('Task/getDeadline'); ?>',
      dataType: 'text',
      success: function(result) {

        if (result == 'success') {

          getTask();

          //initialize toast
          $('.targetToast').html('Task has been updated');
          $('.toast').toast('show');
          var toastElList = [].slice.call(document.querySelectorAll('.toast'))
          var toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, {
              autohide: true,
              delay: 1500
            })
          })

        }

      }
    })

  }

  function addDeadline(taskId, param, key, idForm, key) {

    var today = '<?= date('l'); ?>';
    var tom = '<?= date('l', strtotime('+1 days')); ?>';
    var next = '<?= date('l', strtotime('+7 days')); ?>';


    if (param == 'tomorrow') {

      var paramDate = '<?= date('Y-m-d', strtotime('+1 days')); ?>';

    } else if (param == 'today') {

      var paramDate = '<?= date('Y-m-d'); ?>';

    } else if (param == 'week') {

      var paramDate = '<?= date('Y-m-d', strtotime('+7 days')); ?>';

    }

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId,
        date: paramDate,
        idForm: idForm
      },
      url: '<?= base_url('Task/addSubjobDeadline'); ?>',
      dataType: 'text',
      success: function(result) {

        getTask();
        getSubtask(taskId, key);

      }
    })

  }

  function deleteDeadlineSubtask(taskId, param, key, idForm) {

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId,
        subtaskKey: idForm
      },
      url: '<?= base_url('Task/deleteDeadlineSubtask'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          getSubtask(taskId);
          getTask();

        }

      }
    })

  }

  function addZero(data) {

    if (data < 10) {

      var result = '0' + data;

    } else if (data >= 10) {

      var result = data;

    }

    return result;

  }

  function editTask(taskId, idForm, taskValue) {

    var param = "'manual', 'task'";
    var action = '<td colspan="2" style="border:none; color: var(--suva-gray); font-family: var(--sfpd-light); font-size: 0.9em;">' +
              '<div class="taskForm" style="display: block;">' +
              '<input type="text" autocomplete="off" name="task" class="task" oninput="activeButton('+ param +')" value="'+ taskValue +'">' +
              '</div>' +
              '<div class="buttonGroupAdd" style="display: block;">' +
              '<button type="button" onclick="doEditTask('+ param +', '+ taskId +')" class="editTaskButton activeForButton" name="button">Add Task</button>' +
              '<span onclick="cancelAddTask()">Cancel</span>' +
              '</div>' +
              '</td>';
    $('#trTodo' + idForm).html(action);

    $(".task").on('keyup', function (event) {
        if (event.keyCode === 13) {

          doEditTask('manual', 'task', taskId);
          getTask();

        }
    });

  }

  function editSubtask(taskId, idForm, subtaskValue) {

    var param = "'manual', 'task'";
    var action = '<td colspan="2" style="border:none; color: var(--suva-gray); font-family: var(--sfpd-light); font-size: 0.9em;">' +
              '<div class="subtaskForm" style="display: block">' +
              '<input type="text" autocomplete="off" name="subtaskField" class="subtaskField" oninput="checkSubtask()" value="'+ subtaskValue +'">' +
              '<input type="hidden" name="taskId" class="taskId" value="'+ taskId +'">' +
              '</div>' +
              '<div class="buttonGroupAddSubtask" style="display: block;">' +
              '<button type="button" onclick="doEditSubtask('+ taskId +', '+ idForm +')" class="doAddSubtaskk activeForButton" name="button">Add Task</button>' +
              '<span onclick="cancelAddSubtask('+ taskId +')" style="cursor: pointer;">Cancel</span>' +
              '</div>' +
              '</td>';
    $('#trSubtask' + idForm).html(action);

    $(".subtaskField").on('keyup', function (event) {
        if (event.keyCode === 13) {

          doEditSubtask(taskId, idForm);

        }
    });

  }

  function doEditTask(param, field, taskId) {

    var value = $('.task').val();

    $.ajax({
      type: 'post',
      data: {
        param: param,
        task: value,
        taskId: taskId
      },
      url: '<?= base_url('Task/doEditTask'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          getTask();

          //initialize toast
          $('.targetToast').html('Task has been updated');
          $('.toast').toast('show');
          var toastElList = [].slice.call(document.querySelectorAll('.toast'))
          var toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, {
              autohide: true,
              delay: 1500
            })
          })

        }

      }
    })

  }

  function doEditSubtask(taskId, idForm) {

    var value = $('.subtaskField').val();

    $.ajax({
      type: 'post',
      data: {
        subtask: value,
        taskId: taskId,
        idForm: idForm
      },
      url: '<?= base_url('Task/doEditSubtask'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          getSubtask(taskId);

          //initialize toast
          $('.targetToast').html('Subtask has been updated');
          $('.toast').toast('show');
          var toastElList = [].slice.call(document.querySelectorAll('.toast'))
          var toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, {
              autohide: true,
              delay: 1500
            })
          })

        }

      }
    })

  }

  function confirmDeleteTask(taskId) {

    var param = [];
    param[0] = taskId;

    slModal('Delete Task', 'Are you sure to delete this Task?', 'question', {
        buttons: {
            confirmation: true,
            value: 'confirm',
            onclick: 'delete',
            params: param,
            function: 'deleteTask'
        }
    })

  }

  function deleteTask(taskId) {

    $('#modalNotification').modal('hide');

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId
      },
      url: '<?= base_url('Task/deleteTask'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          getTask();

          //initialize toast
          $('.targetToast').html('Task has been deleted');
          $('.toast').toast('show');
          var toastElList = [].slice.call(document.querySelectorAll('.toast'))
          var toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, {
              autohide: true,
              delay: 1500
            })
          })

        }

      }
    })

  }

  function confirmDeleteSubtask(taskId, subtaskKey) {

    var param = [];
    param[0] = taskId;
    param[1] = subtaskKey;

    slModal('Delete Task', 'Are you sure to delete this Subtask?', 'question', {
        buttons: {
            confirmation: true,
            value: 'confirm',
            onclick: 'delete',
            params: param,
            function: 'deleteSubtask'
        }
    })

  }

  function deleteSubtask(taskId, subtaskKey) {

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId,
        subtaskKey: subtaskKey
      },
      url: '<?= base_url('Task/deleteSubtask'); ?>',
      dataType: 'text',
      success: function(result) {

        $('#modalNotification').modal('hide');

        getTask();
        getSubtask(taskId);

        //initialize toast
        $('.targetToast').html('Subtask has been deleted');
        $('.toast').toast('show');
        var toastElList = [].slice.call(document.querySelectorAll('.toast'))
        var toastList = toastElList.map(function (toastEl) {
          return new bootstrap.Toast(toastEl, {
            autohide: true,
            delay: 1500
          })
        })

      }
    })

  }

  function getComment(taskId) {

    $.ajax({
      type: 'post',
      data: {
        taskId: taskId
      },
      url: '<?= base_url('Task/getComment'); ?>',
      dataType: 'json',
      success: function(result) {

        var com = '';

        for(var i = 0; i < result.comment.length; i++) {

          com += '<div style="display: flex; margin-bottom: 2.5em;">' +
                '<div class="tdIcon">' +
                '<span><?= substr($_SESSION['name'], 0, 1); ?></span>' +
                '</div>' +
                '<div class="">' +
                '<p class="senderComment">'+ result.comment[i].senderEmail +'<span class="timeComment"> '+ result.timePost +'</span> </p>' +
                '<p class="messageComment">'+ result.comment[i].message +'</p>' +
                '</div>' +
                '<div class="optionComment" style="margin-left: 3em; display: none;">' +
                '<i class="fas fa-edit"></i>' +
                '</div>' +
                '</div>';

        }

        $('.chatColomn').html(com);
        $('.commentRow').html(result.comment.length);

        $('.senderComment').on('hover', function() {

          $('.optionComment').show();

        })

      }
    })

  }

  function saveComment(taskId) {

    var comment = $('.commentsValue').val();

    if (comment == '') {

      slModal('Failed', 'Cannot posting zero comment', 'warning', {
        buttons: false,
        timer: 1500
      })

    } else {

      $.ajax({
        type: 'post',
        data: {
          taskId: taskId,
          comment: comment
        },
        url: '<?= base_url('Task/saveComment'); ?>',
        dataType: 'json',
        success: function(result) {

          if (result.message == 'success') {

            getTask();
            getSubtask(taskId);
            getComment(taskId);

            $('.commentsValue').val('');

          }

        }
      })

    }

  }

  function getUserList() {
    $.ajax({
      type: 'post',
      url: '<?= base_url('User/getUserList'); ?>',
      dataType: 'json',
      success: function(result) {

        var tr = '';

        for(var i = 0; i < result.user.length; i ++) {

          tr += '<tr sytle="border-bottom: 1px solid var(--suva-gray)">' +
            '<td style="width: 1em; vertical-align: middle;">' +
            '<i class="fas fa-dot-circle"></i>' +
            '</td>' +
            '<td style="width: auto; vertical-align: middle;">' +
            '<p class="userName">'+ result.name[i] +'</p>' +
            '<p class="userActivity">3 Task on going now</p>' +
            '</td>' +
            '<td style="width: auto; vertical-align: middle;">' +
            '<p class="statusUser">active</p>' +
            '</td>' +
            '<td style="width: 5em; vertical-align: middle;">' +
            '<div class="btn-group">' +
            '<button type="button" class="btn" name="button"> <i class="fas fa-power-off"></i> </button>' +
            '<button type="button" class="btn" name="button"> <i class="fas fa-trash userTrash"></i> </button>' +
            '</div>' +
            '</td>' +
            '</tr>';

        }

        $('.targetUserManagement').html(tr);
        $('.userManagement').show();

      }
    })
  }

  function logout() {

    $.ajax({
      type: 'post',
      url: '<?= base_url('Auth/logout'); ?>',
      dataType: 'json',
      success: function(result) {

        if (result.message == 'success') {

          slModal('Logout success', 'See you again', 'success', {
            buttons: false,
            timer: 1500
          });

          setTimeout(function() {

            var url = '<?= base_url('Auth'); ?>';
            location.href = url;

          }, 1500);

        }

      }
    })

  }

</script>
