<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>

  <meta charset="utf-8">

  <title><?= $title; ?></title>

  <link rel="stylesheet" href="<?= base_url(); ?>/assets/bootstrap-5.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url(); ?>/assets/fontawesome-5/css/fontawesome.min.css">
  <link rel="stylesheet" href="<?= base_url(); ?>/assets/fontawesome-5/css/solid.min.css">
  <link rel="stylesheet" href="<?= base_url(); ?>/assets/fontawesome-5/css/regular.min.css">
  <link rel="stylesheet" href="<?= base_url(); ?>assets/font/sf-font.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.min.css">


  <script src="<?= base_url(); ?>/assets/jquery/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.min.js"></script>
  <script src="<?= base_url(); ?>/assets/anime-master/lib/anime.min.js"></script>
  <script src="<?= base_url(); ?>assets/js/slmodal-1.js"></script>

  <script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 300,
        contentHeight: 300
      });
      calendar.render();
    });
  </script>

  <style media="screen">
    /* keyframe */

    /* slide out */
    @-webkit-keyframes slide-out-elliptic-top-bck {
      0% {
        -webkit-transform: translateY(0) rotateX(0) scale(1);
        transform: translateY(0) rotateX(0) scale(1);
        -webkit-transform-origin: 50% 1400px;
        transform-origin: 50% 1400px;
        opacity: 1;
      }

      100% {
        -webkit-transform: translateY(-600px) rotateX(-30deg) scale(0);
        transform: translateY(-600px) rotateX(-30deg) scale(0);
        -webkit-transform-origin: 50% 100%;
        transform-origin: 50% 100%;
        opacity: 1;
      }
    }

    @keyframes slide-out-elliptic-top-bck {
      0% {
        -webkit-transform: translateY(0) rotateX(0) scale(1);
        transform: translateY(0) rotateX(0) scale(1);
        -webkit-transform-origin: 50% 1400px;
        transform-origin: 50% 1400px;
        opacity: 1;
      }

      100% {
        -webkit-transform: translateY(-600px) rotateX(-30deg) scale(0);
        transform: translateY(-600px) rotateX(-30deg) scale(0);
        -webkit-transform-origin: 50% 100%;
        transform-origin: 50% 100%;
        opacity: 1;
      }
    }


    /* roll in */
    @-webkit-keyframes roll-in-left {
      0% {
        -webkit-transform: translateX(-800px) rotate(-540deg);
        transform: translateX(-800px) rotate(-540deg);
        opacity: 0;
      }

      100% {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg);
        opacity: 1;
      }
    }

    @keyframes roll-in-left {
      0% {
        -webkit-transform: translateX(-800px) rotate(-540deg);
        transform: translateX(-800px) rotate(-540deg);
        opacity: 0;
      }

      100% {
        -webkit-transform: translateX(0) rotate(0deg);
        transform: translateX(0) rotate(0deg);
        opacity: 1;
      }
    }
    @-webkit-keyframes swirl-in-fwd {
      0% {
        -webkit-transform: rotate(-540deg) scale(0);
                transform: rotate(-540deg) scale(0);
        opacity: 0;
      }
      100% {
        -webkit-transform: rotate(0) scale(1);
                transform: rotate(0) scale(1);
        opacity: 1;
      }
    }
    @keyframes swirl-in-fwd {
      0% {
        -webkit-transform: rotate(-540deg) scale(0);
                transform: rotate(-540deg) scale(0);
        opacity: 0;
      }
      100% {
        -webkit-transform: rotate(0) scale(1);
                transform: rotate(0) scale(1);
        opacity: 1;
      }
    }

    /* end keyframe */

    /* slmodal style */

    .swirl-in-fwd {
    	-webkit-animation: swirl-in-fwd 0.6s ease-out both;
    	        animation: swirl-in-fwd 0.6s ease-out both;
    }

    #modalNotification > .modal-dialog > .modal-content {
      background: #fff;
      border-radius: 1rem;
    }

    #modalNotification > .modal-dialog > .modal-content > .modal-body {
      padding: 1em 0 0 0;
    }

    .iconInfo {
      text-align: center;
    }

    #targetDescNotif {
      text-align: center;
      margin-top: 1rem;
      font-family: var(--sfpd-regular);
    }

    .footerNotif {
      width: 100%;
      display: flex;
      margin-top: 2em;
      border-top: 1px solid var(--suva-gray);
      padding: 0 1em;
      display: none;
    }

    .footerNotif1 {
      width: 100%;
      display: flex;
      margin-top: 2em;
      border-top: 1px solid var(--suva-gray);
      padding: 0 1em;
      text-align: center;
      display: none;
    }

    .confirmFull,
    .cancelFull {
      width: 100%;
      text-align: center;
      padding: 1em;
    }

    .confirmNotif {
      width: 50%;
      text-align: center;
      border-left: 1px solid var(--suva-gray);
      padding: 1em;
    }

    .cancelNotif {
      width: 50%;
      text-align: center;
      padding: 1em;
    }

    .confrimButtonSlModal {
      color: #0b72f0;
      text-transform: uppercase;
      text-align: center;
      background: transparent;
      border: none;
      font-family: var(--sfpd-heavy) !important;
      font-size: 0.9em;
    }

    .cancelButtonSlModal {
      text-transform: uppercase;
      text-align: center;
      color: #f00b41;
      background: transparent;
      border: none;
      font-family: var(--sfpd-heavy) !important;
      font-size: 0.9em;
    }

    /* end slmodal style */

    html {
      --black: #000;
      --white: #fff;
      --dim-gray: #5e5e5e;
      --suva-gray: #929292;
      --light-gray: #d5d5d5;
      --silver: #c2c2c2;
      --solitude: #f2f2f7;
      --white-lilac: #e0e0e5;
      --deep-sky-blue: #00a2ff;
      --misty-rose: #ffdbd8;
      --tomato: #ff644e;
      --sandybrown: #f4a460;
      --gold: #FFD700;
      --sfpd-regular: "SF Pro Display Regular";
      --sfpd-bold: "SF Pro Display Bold";
      --sfpd-semibold: "SF Pro Display Semibold";
      --sfpd-heavy: "SF Pro Display Heavy";
      --sfpd-medium: "SF Pro Display Medium";
      --sfpd-light: "SF Pro Display Light";
      --sfpd-ultralight: "SF Pro Display Ultra Light";
      --sfpd-thin: "SF Pro Display Thin";
      --fs-default: .750rem;
      --br-default: .750rem;
      font-family: var(--sfpd-regular) !important;
      caret-color: var(--deep-sky-blue);
    }

    body,
    html {
      height: 100%;
      background: #1f1f1f;
      overflow: hidden;
    }



    .slide-out-elliptic-top-bck {
      -webkit-animation: slide-out-elliptic-top-bck 0.7s ease-in both;
      animation: slide-out-elliptic-top-bck 0.7s ease-in both;
    }

    .roll-in-left {
      -webkit-animation: roll-in-left 0.6s ease-out both;
      animation: roll-in-left 0.6s ease-out both;
    }

    .colSidenav {
      height: 100vh;
      background: #282828;
    }

    .sideNav {
      margin-top: 3.3em;
    }

    .colSidenav > .sideNav > .list-group > .list-group-item {
      background: transparent;
      color: #fff;
      border: none;
      margin: 0.5em 0;
      align-items: center;
      cursor: pointer;
    }

    .mainTab {
      padding: 0;
    }

    .header {
      padding: 0.5em 0.9em;
      background: #282828;
      width: 100%;
      border-bottom: 1px solid black;
    }

    .userAvatar {
      border-radius: 50%;
      background: #4fff3d;
    }

    .main {
      padding: 2em 2.4em;
    }

    .todayTitle {
      margin: 1em 0.8em;
    }

    .spanTodayTitle {
      color: #fff;
      font-family: var(--sfpd-regular);
      font-size: 1.2em;
      text-transform: uppercase;
    }

    .spanDate {
      color: var(--suva-gray);
      font-family: var(--sfpd-light);
      font-size: 0.8em;
    }

    .todayTable{
      margin-top: 3em;
    }

    .taskDoneTable {
      margin-top: 3em;
      /* display: none; */
    }

    .targetOwnerTask {
      text-transform: capitalize;
      color: #fff;
      font-size: 0.9em;
      font-family: var(--sfpd-regular);
    }

    .iconTodayTable {
      width: 2em;
      border-color: #4d4c4c;
      vertical-align: middle;
      align-items: center;
      line-height: 2.5em;
    }

    td.descTodayTable,
    td.descSubtask {
      max-width: 10em;
      width: auto;
      color: #fff;
      font-family: var(--sfpd-thin);
      border-color: #4d4c4c;
      vertical-align: middle;
      align-items: center;
      cursor: pointer;
    }

    td.descSubtask > p {
      max-width: 20em;
      overflow: scroll;
    }

    td.descTodayTable > p {
      max-width: 20em;
      width: 20em;
      white-space: nowrap;
      text-overflow: ellipsis;
      overflow: hidden;
    }

    td.tdAction {
      width: 2em;
      color: #fff;
      font-family: var(--sfpd-thin);
      border-color: #4d4c4c;
      vertical-align: middle;
      align-items: center;
      cursor: pointer;
    }

    .btn:focus {
      box-shadow: none !important;
    }

    .rtr {
      transform: rotate(5deg) !important;
    }

    .customBadge {
      height: 8px;
      width: 8px;
      background: red;
      border-radius: 50%;
      color: red;
      display: inline-flex;
      margin: 0;
      margin-right: 0.3em;
    }

    .titleProject {
      color: #fff;
      font-family: var(--sfpd-light);
      font-size: 0.9em;
    }

    .counter {
      color: var(--suva-gray);
      font-size: 0.8em;
    }

    .masterProject {
      margin-bottom: 0.8em;
    }

    .masterCounter {
      margin-bottom: 0.8em;
    }

    .activeItem {
      background: #363636 !important;
    }

    .taskForm {
      width: 100%;
      background: #262525;
      height: 5em;
      border-radius: 0.8em;
      border: 1px solid #b4b2b2;
      padding: 0.8em;
      display: none;
    }

    .subtaskForm {
      width: 100%;
      background: #262525;
      height: 5em;
      border-radius: 0.8em;
      border: 1px solid #b4b2b2;
      padding: 0.8em;
      display: none;
    }

    .quickForm {
      width: 100%;
      background: #262525;
      height: 5em;
      border-radius: 0.8em;
      border: 1px solid #b4b2b2;
      padding: 0.8em;
    }

    .taskForm > input,
    .subtaskForm > input,
    .quickForm > input {
      width: 100%;
      background: transparent;
      border: none;
      color: var(--suva-gray);
    }

    .taskForm > input:focus,
    .subtaskForm > input:focus,
    .quickForm > input:focus {
      outline: none;
    }

    .subtaskForm > input::placeholder {
      font-size: 0.9em;
      font-family: var(--sfpd-light);
      color: var(--dim-gray);
    }

    .subTask {
      cursor: pointer;
    }

    .subTask > span:hover,
    .subTask > img:hover {
      color: #fff !important;
    }

    .buttonTaskForm,
    .buttonSubtask {
      cursor: pointer;
    }

    .spanAddFormModal {
      margin-left: 0.7em;
      color: var(--suva-gray);
      font-family: var(--sfpd-light);
    }

    .spanAddFormModal:hover {
      color: #fff;
    }

    .buttonGroupAdd,
    .buttonGroupAddSubtask {
      margin-top: 0.5em;
      display: none;
    }

    .doAddTask,
    .doAddSubtask,
    .doAddSubtaskk,
    .editTaskButton {
      background: #532e2d;
      border: none;
      outline: none;
      border-radius: 0.3em;
      margin-right: 0.5em;
      font-family: var(--sfpd-ligth);
      color: #615f5f;
    }

    .activeForButton {
      background: #cf5650 !important;
      color: #fff !important;
    }

    .background {
      text-align: center;
      display: none;
    }

    .headerDetail {
      border: none;
    }

    .contentDetail {
      background: #282828;
      border-radius: 0.8em;
      max-height: 30em;
      height: 50em;
    }

    .targetTitleDetail {
      color: var(--silver);
      font-family: var(--sfpd-regular);
      font-size: 1em;
      text-transform: capitalize;
      margin-left: 0.5em;
    }

    .parentTabsDetail {
      text-align: center;
      margin-top: 3em;
      padding: 0 3.5em;
    }

    .parentTabsDetail div {
      border-bottom: 1px solid var(--dim-gray);
    }

    .activeTab {
      border-bottom: 1px solid var(--silver) !important;
    }

    .activeTab > span {
      color: #fff !important;
    }

    .parentTabsDetail div span {
      color: var(--dim-gray);
      font-family: var(--sfpd-light);
      font-size: 0.9em;
    }

    .flexibleDetail {
      padding: 0.5em 3em;
      margin-top: 1em;
    }

    .targetSubtask {
      padding: 0.8em 1.8em;
    }

    .tdEllipsis {
      width: 2em;
      border-color: #4d4c4c;
      cursor: pointer;
    }

    .popoverTask > li {
      background: #4c4c4c;
      border: none;
      color: #fff;
      cursor: pointer;
    }

    li.deleteTask {
      border-bottom: 1px solid var(--suva-gray) !important;
    }

    li.buttonDeadlineTask {
      display: flex;
      justify-content: space-around;
    }

    .popoverTask > li:hover {
      color: var(--silver);
    }

    .btnPopover {
      margin: 0 1em !important;
    }

    .fa-calendar-check,
    .fa-calendar-day {
      color: #5AE60E;
      font-size: 1.2em;
    }

    .fa-sun {
      color: #FDCD1F;
      font-size: 1.2em;
    }

    .fa-edit,
    .fa-trash {
      color: var(--suva-gray);
      font-size: 1.2em;
    }

    .fa-couch {
      color: #22C4F5;
      font-size: 1.2em;
    }

    .fa-calendar-week {
      color: #AB22F5;
      font-size: 1.2em;
    }

    .fa-calendar-times {
      color: var(--tomato);
      font-size: 1.2em;
    }

    .noDate {
      display: none;
    }

    .far.fa-calendar.today {
      color: #5AE60E;
      margin-right: 0.5em;
    }

    .far.fa-calendar.tomorrow {
      color: #FDCD1F;
      margin-right: 0.5em;
    }

    .far.fa-calendar.week {
      color: #AB22F5;
      margin-right: 0.5em;
    }

    .far.fa-calendar.overdue {
      color: #ff0303;
      margin-right: 0.5em;
    }

    .todaySubtask {
      color: #5AE60E;
      margin: 0;
      font-size: 0.8em;
      font-family: var(--sfpd-regular);
    }

    .tomorrowSubtask {
      color: #FDCD1F;
      margin: 0;
      font-size: 0.8em;
      font-family: var(--sfpd-regular);
    }

    .weekSubtask {
      color: #AB22F5;
      margin: 0;
      font-size: 0.8em;
      font-family: var(--sfpd-regular);
    }

    .overdueSubtask {
      color: #ff0303;
      margin: 0;
      font-size: 0.8em;
      font-family: var(--sfpd-regular);
    }



    .todayPopover,
    .todayPopoverr,
    .tomorrowPopover,
    .weekendPopover,
    .weekPopover,
    .clearDatePopover {
      padding: 0;
      margin: 0;
      font-size: 0.8em;
      font-family: var(--sfpd-light);
    }

    .todayPopover,
    .todayPopoverr, {
      color: #5AE60E;
    }

    .tomorrowPopover {
      color: #FDCD1F;
    }

    .weekendPopover {
      color: #22C4F5;
    }

    .weekPopover {
      color: #AB22F5;
    }

    .clearDatePopover {
      color: var(--suva-gray);
    }

    .toast {
      background: #282828;
      box-shadow: 4px 7px 26px 7px rgba(0,0,0,0.75);
      -webkit-box-shadow: 4px 7px 26px 7px rgba(0,0,0,0.75);
      -moz-box-shadow: 4px 7px 26px 7px rgba(0,0,0,0.75);
      color: #fff;
      z-index: 10001;
    }

    .toast-header {
       background: #282828;
    }

    .toast-header > span {
      font-family: var(--sfpd-bold);
      text-transform: capitalize;
      font-size: 1.2em;
    }

    .addedTime {
      border-bottom: 1px solid var(--dim-gray);
      padding: 0 0 0.8em 0;
    }

    .spanAddedTime {
      color: #fff;
      font-family: var(--sfpd-medium);
      text-transform: capitalize;
      font-size: 0.9em;
    }

    .detailActivity {
      margin-top: 0.8em;
    }

    .detailActivity > .table-responsive > table > tbody > tr {
      border-bottom: 1px solid var(--dim-gray);
      padding: 0.3em 0;
    }

    .icon {
      height: 2.3em;
      width: 2.4em;
      background: green;
      border-radius: 50%;
      text-align: center;
      justify-content: center;
      align-items: center;
    }

    .icon > span {
      text-transform: capitalize;
      color: #fff;
      font-size: 1.4em;
      margin-left: 0.1em;
    }

    .chatColomn {
      height: 25em;
      max-height: 25em;
      overflow: scroll;
      width: 100%;
      cursor: pointer;
    }

    .typeComments {
      height: 7em;
      width: 100%;
      border: 0.5px solid var(--suva-gray);
      padding: 0.4em;
      border-radius: 0.8em;
    }

    .typeComments > textarea {
      width: 100%;
      background: transparent;
      height: 4em;
      border: none;
      box-shadow: none;
      border-bottom: 1px solid var(--suva-gray);
      padding: 0.4em 0.5em;
      color: #fff;
    }

    .typeComments > textarea:focus {
      outline: none;
    }

    .actionComments {
      vertical-align: middle;
      text-align: right;
    }

    .actionComments > button {
      background: var(--tomato) !important;
      border-radius: 0.5em;
      border: none;
      padding: 0.4em;
      color: #fff;
      font-size: 0.8em;
    }

    .tdIcon {
      background: green;
      text-align: center;
      border-radius: 50%;
      height: 1.5em;
      width: 1.5em;
      margin-right: 0.7em;
    }

    .senderComment {
      padding: 0;
      color: var(--silver);
      font-family: var(--sfpd-medium);
      font-size: 1.1em;
    }

    .timeComment {
      color: var(--suva-gray);
      font-family: var(--sfpd-light);
      font-size: 0.8em;
      margin-left: 0.5em;
    }

    .messageComment {
      padding: 0;
      margin-bottom: 0 !important;
      color: var(--silver);
      font-family: var(--sfpd-regular);
      font-size: 0.9em;
    }

    .far.fa-comment {
      color: var(--suva-gray);
      margin-right: 0.2em;
    }

    .userManagement {
      display: none;
      margin-top: 1em;
      padding: 0.2em 4em;
    }

    .fa-dot-circle {
      color: var(--dim-gray);
    }

    .fas.fa-power-off {
      color: red;
      font-size: 0.9em;
    }

    .fas.fa-trash.userTrash {
      color: var(--dim-gray);
      font-size: 0.9em;
    }

    .userName {
      color: #fff;
      font-size: 0.9em;
      margin-bottom: 0;
      font-family: var(--sfpd-regular);
    }

    .userActivity {
      color: var(--dim-gray);
      font-size: 0.7em;
      font-family: var(--sfpd-light);
    }

    .statusUser {
      color: #fff;
      font-size: 0.9em;
      font-family: var(--sfpd-regular);
      margin-bottom: 0;
    }

    .addUserContent {
      background: #282828;
      border-radius: 0.8em;
    }

    .addUserContent > .modal-header {
      border: none;
      color: #fff;
      text-family: var(--sfpd-regular);
      font-size: 0.9em;
    }

    .addUserList {
      background: transparent;
      box-shadow: none;
      border: none;
      border-bottom: 1px solid black;
      color: #fff;
      font-size: 0.8em;
      font-family: var(--sfpd-light);
      margin-top: 0.8em;
    }

    .addUserList:focus {
      background: transparent;
      outline: none;
      color: #fff;
      box-shadow: none;
      border: none;
      border-bottom: 1px solid black;
    }

    .addUserList > option {
      color: #fff;
    }

    .saveUser {
      width: 100%;
      color: #fff;
      font-family: var(--sfpd-bold);
      background: #ffc38d;
      padding: 0.2em 0.4em;
      margin-top: 1.5em;
    }

    .userShow {
      display: flex;
    }

    /* media for fixed elements */

    @media screen and (min-width: 576px) and (max-width: 769px) {

      .headerDetailSubtask {
        position: fixed;
        width: 50%;
        text-align: center;
      }

    }

    @media screen and (min-width: 769px) and (max-width: 1200px) {

      .headerDetailSubtask {
        position: fixed;
        width: 50%;
        text-align: center;
      }

    }

    /* media for fixed elements */
  </style>

</head>

<body>

  <div class="row">

    <div class="col-lg-3 col-md-3 colSidenav">

      <div class="sideNav">

        <ul class="list-group">

          <li class="list-group-item userTab" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><img src="<?= base_url(); ?>/assets/images/usermanagement.png" width="20" height="20" alt=""><span style="margin-left: 0.8em;">User</span></li>

          <div class="collapse collapseUser" id="collapseExample">
            <ul class="list-group">
              <li class="list-group-item" style="background: #282828 !important; color: var(--suva-gray); cursor: pointer; border: none;" onclick="addUser()"> <img src="<?= base_url(); ?>/assets/images/adduser.png" width="20" height="20" style="margin=left: 0.9em;" alt=""> Add User</li>
              <li class="list-group-item" style="background: #282828 !important; color: var(--suva-gray); cursor: pointer; border: none;"> <img src="<?= base_url(); ?>/assets/images/usergroup.png" width="20" height="20" style="margin=left: 0.9em;" alt=""> Manage User</li>
            </ul>
          </div>

          <li class="list-group-item todayTab activeItem" data-bs-toggle="collapse" href="#collapseTodayTask" role="button" aria-expanded="false" aria-controls="collapseTodayTask"><img src="<?= base_url(); ?>/assets/images/todaycalendar.png" width="20" height="20" alt=""><span style="margin-left: 0.8em;">Today</span></li>

          <div class="collapse collapseTask" id="collapseExample">
            <ul class="list-group">
              <div class="self">

              </div>
              <div class="targetCollapseButtonUser">

              </div>
              <!-- <li class="list-group-item" style="background: #282828 !important; color: var(--suva-gray); cursor: pointer; border: none;" onclick="addUser()"> <img src="<?= base_url(); ?>/assets/images/adduser.png" width="20" height="20" style="margin=left: 0.9em;" alt=""> Add User</li>
              <li class="list-group-item" style="background: #282828 !important; color: var(--suva-gray); cursor: pointer; border: none;"> <img src="<?= base_url(); ?>/assets/images/usergroup.png" width="20" height="20" style="margin=left: 0.9em;" alt=""> Manage User</li> -->
            </ul>
          </div>

          <li class="list-group-item upcomingTab"><img src="<?= base_url(); ?>/assets/images/upcomingcalendar.png" width="20" height="20" alt=""> <span style="margin-left: 0.8em;">Upcoming</span></li>

        </ul>

      </div>

    </div>

    <!-- modal add user -->

    <div class="modal modalAddUser fade" id="exampleModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content addUserContent">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="" style="color: #fff; font-family: var(--sfpd-light); font-size: 0.9em;">Choose User</label>
              <select class="form-control addUserList" name="addUserList">
              </select>
            </div>
            <div class="form-group">
              <button type="button" class="btn saveUser" onclick="saveUser()" name="saveUser">Save User</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- end modal add user -->
